import React from 'react';
import './Card1.css';
import paper3 from '../Images/paper3.jpg';

const Card3 = () => {
  return (
    <div className="card1-vid">
      <img src={paper3} />
      <div className="card1-content-div">
      </div>
    </div>
  );
};

export default Card3;
