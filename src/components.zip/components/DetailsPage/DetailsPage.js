import React from "react";
import { FaArrowLeft, FaPhoneAlt } from "react-icons/fa";
import "./DetailsPage.css";
import p1 from "../Images/p1.png";
import p2 from "../Images/p2.png";
import p3 from "../Images/p3.png";

const products = [
  { id: 1, title: "Majestic Print", description: ["Available in - 50 to 120 gsm", "High-quality texture", "Eco-friendly material"], image: p1 },
  { id: 2, title: "Vector Print", description: ["Available in - 50 to 120 gsm", "Sharp vector detailing", "Ideal for premium prints"], image: p2 },
  { id: 3, title: "Supernova (HB)", description: ["Available in - 70 to 150 gsm", "Glossy & matte options", "Perfect for books & brochures"], image: p3 },
  { id: 4, title: "Majestic Print", description: ["Available in - 50 to 120 gsm", "Premium paper quality", "Best for high-end designs"], image: p1 },
];

const DetailsPage = ({ productId, changePage }) => {
  const product = products.find((p) => p.id === productId);

  if (!product) {
    return <h2>Product not found</h2>;
  }

  return (
    <div className="product-details-container1">
      <button className="back-button-a" onClick={() => changePage("home")}>
        <FaArrowLeft /> Back
      </button>

      <img src={product.image} alt={product.title} className="product-image1" />

      <div className="product-info1">
        <h2>{product.title}</h2>

        <ul>
          {product.description.map((point, index) => (
            <li key={index}>{point}</li>
          ))}
        </ul>

        <a href="tel:+91 81496-30970" className="contact-button1">
          <FaPhoneAlt /> Contact Us
        </a>
      </div>
    </div>
  );
};

export default DetailsPage;

// import React from "react";
// import { FaArrowLeft } from "react-icons/fa";
// import "./DetailsPage.css";
// import p1 from "../Images/p1.png";
// import p2 from "../Images/p2.png";
// import p3 from "../Images/p3.png";

// const products = [
//   { id: 1, title: "Majestic Print", description: "Available in - 50 to 120 gsm", image: p1 },
//   { id: 2, title: "Vector Print", description: "Available in - 50 to 120 gsm", image: p2 },
//   { id: 3, title: "Supernova (HB)", description: "Available in - 70 to 150 gsm", image: p3 },
//   { id: 4, title: "Majestic Print", description: "Available in - 50 to 120 gsm", image: p1 },
// ];

// const ProductDetails = ({ productId, changePage }) => {
//   const product = products.find((p) => p.id === productId);

//   if (!product) {
//     return <h2>Product not found</h2>;
//   }

//   return (
//     <div className="product-details-container">
//       {/* Back Button */}
//       <button className="back-button-a" onClick={() => changePage("home")}>
//         <FaArrowLeft /> Back
//       </button>

//       <img src={product.image} alt={product.title} className="product-image" />
//       <div className="product-info">
//         <h2>{product.title}</h2>
//         <p>{product.description}</p>
//       </div>
//     </div>
//   );
// };

// export default ProductDetails;
