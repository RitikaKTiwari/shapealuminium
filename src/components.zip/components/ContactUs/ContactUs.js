// import React, { useState } from "react";
// import { motion } from "framer-motion";
// import "./ContactUs.css";
// import paper12 from "../Images/paper4.png";
// const ContactUs = () => {
//   const [formData, setFormData] = useState({
//     name: "",
//     email: "",
//     phone: "",
//     message: "",
//   });

//   const [submitted, setSubmitted] = useState(false);

//   const handleChange = (e) => {
//     setFormData({ ...formData, [e.target.name]: e.target.value });
//   };

//   const handleSubmit = (e) => {
//     e.preventDefault();

//     const { name, email, message, phone } = formData;

//     if (name.trim() === "" || email.trim() === "" || message.trim() === "" || phone.trim() === "" || phone.length !== 10) {
//       alert("Please fill in all required fields.");
//       return;
//     }

//     alert("Message sent successfully!");
//     setSubmitted(true);
//     setFormData({ name: "", email: "", phone: "", message: "" });
//   };

//   return (
//     <div className="contact-page">
//       {/* Hero Section */}
//       {/* <div className="hero">
//           <div className="overlay">
//             <h1>Contact Us</h1>
//             <p>Home &gt; Contact Us</p>
//           </div>
//         </div> */}
//       <div className="cont-hero-section">
//         <img src={paper12} alt="Paper Rolls" className="cont-hero-image" />
//         <div className="cont-hero-overlay">
//           <h1>Contact Us</h1>
//           <p>Home &gt; Contact Us</p>
//         </div>
//       </div>
//       {/* Contact Section */}
//       <div className="contact-section">
//         <motion.div
//           className="contact-info"
//           initial={{ opacity: 0, x: -50 }}
//           animate={{ opacity: 1, x: 0 }}
//           transition={{ duration: 1 }}
//         >
//           <h2>Get in touch with our expert agents</h2>
//           <p>
//             Our success is determined not only by results but also by how we
//             achieve them.
//           </p>
//           <div className="cont-info-item">📞 +91 81496-30970</div>
//           <div className="cont-info-item">📧 aum.enterprises236@gmail.com</div>
//           <div className="cont-info-item1">
//             <span className="cont-info-address"> 📍 Gala no 205 Gopal House</span>
//             <br />
//             <span className="cont-info-address">I B Patel road Goregaon East</span>
//             <br />
//             <span className="cont-info-address">Mumbai 400063</span>
//           </div>
//         </motion.div>

//         {/* Contact Form */}
//         <motion.form
//           className="contact-form"
//           onSubmit={handleSubmit}
//           initial={{ opacity: 0, x: 50 }}
//           animate={{ opacity: 1, x: 0 }}
//           transition={{ duration: 1 }}
//         >
//           <input
//             type="text"
//             name="name"
//             placeholder="Your Name"
//             value={formData.name}
//             onChange={handleChange}
//             required
//           />
//           <input
//             type="email"
//             name="email"
//             placeholder="Email Address"
//             value={formData.email}
//             onChange={handleChange}
//             required
//           />
//           <input
//             type="text"
//             name="phone"
//             placeholder="Phone Number"
//             value={formData.phone}
//             onChange={handleChange}
//           />
//           <textarea
//             name="message"
//             placeholder="Write a Message"
//             value={formData.message}
//             onChange={handleChange}
//             required
//           />
//           <button type="submit">Send a Message</button>
//         </motion.form>
//       </div>

//       {/* Map Section */}
//       {/* <div className="map">
//           <iframe
//             title="map"
//             src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3769.541568275779!2d72.85911807499802!3d19.129438749033026!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7b61fc4cb7c03%3A0x370e2b6312b5a37a!2sGala%20No%20205%2C%20Gopal%20House%2C%20I%20B%20Patel%20Road%2C%20Goregaon%20East%2C%20Mumbai%20400063!5e0!3m2!1sen!2sin!4v1710416512345"            allowFullScreen=""
//             loading="lazy"
//           ></iframe>
//         </div> */}

//       {/* Map Section with Text Content */}
//       <div className="map-container">
//         <div className="map">
//           <iframe
//             title="map"
//             src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3769.541568275779!2d72.85911807499802!3d19.129438749033026!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7b61fc4cb7c03%3A0x370e2b6312b5a37a!2sGala%20No%20205%2C%20Gopal%20House%2C%20I%20B%20Patel%20Road%2C%20Goregaon%20East%2C%20Mumbai%20400063!5e0!3m2!1sen!2sin!4v1710416512345"
//             allowFullScreen=""
//             loading="lazy"
//           ></iframe>
//         </div>

//         {/* <div className="contct-text-content">
//           <h2>
//             <span>Let's Connect</span>
//           </h2>
//           <p>
//             Have a question? Need assistance? Our team is always available to help you with any inquiries.
//             Whether it's about our products, services, or general information, we're here to provide you with
//             the best support.
//           </p>
//           <p>
//             We believe in building strong relationships with our customers. Reach out to us, and let's explore
//             how we can collaborate for a better future.
//           </p>
//           <button className="contct-btn">Get in Touch</button>
//         </div> */}
//       </div> 

//     </div>
//   );
// };

// export default ContactUs;
import React from "react";
import "./ContactUs.css";
import paper12 from "../Images/paper4.png";

const ContactUs = () => {
  return (
    <div className="contact-page">
      <div className="cont-hero-section">
        <img src={paper12} alt="Paper Rolls" className="cont-hero-image" />
        <div className="cont-hero-overlay">
          <h1>Contact Us</h1>
          <p>Home &gt; Contact Us</p>
        </div>
      </div>
      <div className="contact-container">
        {/* Left - Contact Form */}
        <div className="contact-form">
          <h2>Write to us</h2>
          <input type="text" placeholder="Full Name" />
          <input type="email" placeholder="Email Address" />
          <input type="tel" placeholder="Phone Number" />
          <textarea placeholder="Write a Comment"></textarea>
          <button type="submit">SUBMIT</button>
        </div>

        {/* Right - Contact Info */}
        <div className="contact-info">
          <h2>Get in touch</h2>
          <p><strong>ADDRESS</strong></p>
          <p>Sales & Marketing</p>
          <p>Bilt Graphic Paper Products Limited</p>
          <p>📍 Gala no 205 Gopal House – I B Patel road Goregaon East – Mumbai 400063, India</p>
          <p><strong>Email :</strong> <a href="mailto:aum.enterprises236@gmail.com">📧 aum.enterprises236@gmail.com</a></p>
          <p><strong>Phone :</strong> <a href="tel:+918149630970">📞 +91 81496-30970</a></p>

          {/* Google Map */}
          <div className="map-container">
            <iframe
              title="map"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3769.541568275779!2d72.85911807499802!3d19.129438749033026!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7b61fc4cb7c03%3A0x370e2b6312b5a37a!2sGala%20No%20205%2C%20Gopal%20House%2C%20I%20B%20Patel%20Road%2C%20Goregaon%20East%2C%20Mumbai%20400063!5e0!3m2!1sen!2sin!4v1710416512345"
              allowFullScreen=""
              loading="lazy"
            ></iframe>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ContactUs;
