import React, { useState } from "react";
import "./Footer.css";
import ContactUs from "../ContactUs/ContactUs"; // Import the ContactUs component

const Footer = ({ changePage }) => {

  const handleNavigation = (page) => {
    changePage(page);
    window.scrollTo(0, 0); // Scrolls to the top of the page
  };

  return (
    <div className="foot-box">
      <div className="FooterContainer">
        <div className="Row-foot">
          <div className="Column-foot">
            <div className="Heading">About Us</div>
            <span className="FooterLink" onClick={() => handleNavigation("about")} style={{ cursor: "pointer" }}>Who We Are</span>
            <span className="FooterLink" onClick={() => handleNavigation("contact")} style={{ cursor: "pointer" }}>Contact Us</span>
          </div>

          <div className="Column">
            <div className="Heading">Follow Us</div>
            <a className="FooterLink" href="https://www.instagram.com/" target="_blank" rel="noopener noreferrer">Instagram</a>
            <a className="FooterLink" href="https://www.youtube.com/" target="_blank" rel="noopener noreferrer">YouTube</a>
            <a className="FooterLink" href="https://twitter.com/?lang=en" target="_blank" rel="noopener noreferrer">Twitter</a>
          </div>
          <div className="Column">
            <div className="Heading">Privacy & Legal</div>
            <span className="FooterLink">Privacy Policy</span>
          </div>
        </div>
      </div>

      {/* Footer Bottom Section */}
      <div className="footer-bottom">
        <p>© 2025 AUM Enterprises. All rights reserved.</p>
      </div>
    </div>
  );
};

export default Footer;