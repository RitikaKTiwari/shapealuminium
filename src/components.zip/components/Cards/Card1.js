import paper1 from "../Images/paper1.jpg";
import React from "react";
import "./Card1.css";

const Card1 = () => {
  return (
    <div className="card1-vid">
      <img src={paper1} />
      <div className="card1-content-div">
      </div>
    </div>
  );
};

export default Card1;
