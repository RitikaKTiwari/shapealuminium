import React, { useState } from "react";
import "./ProductGrid.css";
import p1 from "../Images/p1.png";
import p2 from "../Images/p2.png";
import p3 from "../Images/p3.png";

const products = [
  {
    id: 1,
    title: "Majestic Print",
    description: "Available in - 50 to 120 gsm",
    image: p1,
  },
  {
    id: 2,
    title: "Vector Print",
    description: "Available in - 50 to 120 gsm",
    image: p2,
  },
  {
    id: 3,
    title: "Supernova (HB)",
    description: "Available in - 70 to 150 gsm",
    image: p3,
  },
  {
    id: 4,
    title: "Majestic Print",
    description: "Available in - 50 to 120 gsm",
    image: p1,
  },
];

const ProductCard = ({ product, onClick, changePage }) => {

  const handleDetailsClick = (e) => {
    e.stopPropagation();
    if (typeof changePage === "function") {
      changePage(`product/${product.id}`, product.id);
      window.scrollTo(0, 0); // Scrolls to the top of the page
    }
  };

  return (
    <div className="product-card" onClick={() => onClick(product)}>
      <img src={product.image} alt={product.title} />
      <div className="product-info">
        <div>
          <h3 className="product-title">{product.title}</h3>
          <p className="product-description">{product.description}</p>
        </div>
        <button className="more-details" onClick={handleDetailsClick}>
          More Details
        </button>
      </div>
    </div>
  );
};


const ProductGrid = ({ setIsModalOpen, changePage }) => {
  const [selectedProduct, setSelectedProduct] = useState(null);

  const openModal = (product) => {
    setSelectedProduct(product);
    setIsModalOpen(true); // Pause animation
  };

  const closeModal = () => {
    setSelectedProduct(null);
    setIsModalOpen(false); // Resume animation
  };

  return (
    <div className="container">
      <div className="our-product-title">
        <p>Our Products</p>
      </div>
      <div className="product-grid">
        {products.map((product) => (
          <ProductCard key={product.id} product={product} onClick={openModal} changePage={changePage} />
        ))}
      </div>

      {/* Modal */}
      {selectedProduct && (
        <div className="modal" onClick={closeModal}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <span className="close" onClick={closeModal}>&times;</span>
            <img src={selectedProduct.image} alt={selectedProduct.title} className="modal-image" />
            <h3>{selectedProduct.title}</h3>
            <p>{selectedProduct.description}</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default ProductGrid;
