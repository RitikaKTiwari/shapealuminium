import { useState, useEffect, useRef } from "react";
import { motion } from "framer-motion";
import Card1 from "./Card1";
import Card2 from "./Card2";
import Card3 from "./Card3";
import BathroomCard from "./BathroomCard";
import "./CardSliding.css";

import { FiPhone } from "react-icons/fi";
const cards = [
    <Card1 />,
    <Card2 />,
    <Card3 />,
    <BathroomCard />


];

export default function CardSliding({ isPaused }) {
    const [index, setIndex] = useState(0);
    const [showPhone, setShowPhone] = useState(false);
    const phoneRef = useRef(null);

    useEffect(() => {
        if (isPaused) return; // Stop animation when modal is open

        const interval = setInterval(() => {
            setIndex((prevIndex) => (prevIndex + 1) % cards.length);
        }, 3000);

        return () => clearInterval(interval);
    }, [isPaused]); // Re-run effect when isPaused changes

    // Toggle phone number visibility
    const togglePhoneNumber = () => {
        setShowPhone(!showPhone);
    };

    // Close phone number if clicked outside
    useEffect(() => {
        const handleClickOutside = (event) => {
            if (phoneRef.current && !phoneRef.current.contains(event.target)) {
                setShowPhone(false);
            }
        };

        document.addEventListener("mousedown", handleClickOutside);
        return () => {
            document.removeEventListener("mousedown", handleClickOutside);
        };
    }, []);

    return (
        <div className="relative w-full h-[50vh] mx-auto overflow-hidden">
            <motion.div
                key={index}
                className="w-full h-full flex items-center justify-center"
                initial={{ opacity: 0, x: 100 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -100 }}
                transition={{ duration: 0.5 }}
            >
                <div className="w-full h-full flex items-center justify-center bg-white">
                    {cards[index]}
                </div>
            </motion.div>

            {/* Phone Icon on the Right Side */}
            <div className="phone-icon-container" ref={phoneRef}>
                <div className="phone-icon" onClick={togglePhoneNumber}>
                    <FiPhone size={24} />
                </div>
                {showPhone && (
                    <div className="phone-number"><a href="tel:+918149630970">📞 +91 81496-30970</a></div>
                )}
            </div>
        </div>
    );
}