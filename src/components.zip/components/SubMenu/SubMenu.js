import React, { useState } from "react";
import "./Sb.css";

const SubMenu = ({ items }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div
      className="submenu-container"
      onMouseEnter={() => setIsOpen(true)}
      onMouseLeave={() => setIsOpen(false)}
    >
      <div className={`submenu ${isOpen ? "open" : ""}`}>
        {items.map((item, index) => (
          <a key={index} href="#">
            {item}
          </a>
        ))}
      </div>
    </div>
  );
};

export default SubMenu;

// import React, { useState } from "react";
// import "./SubMenu.css";

// const SubMenu = ({ title, items }) => {
//   const [isOpen, setIsOpen] = useState(false);

//   return (
//     <div
//       className="submenu-container"
//       onMouseEnter={() => setIsOpen(true)}
//       onMouseLeave={() => setIsOpen(false)}
//     >
//       <span className="submenu-title">{title}</span>
//       {isOpen && (
//         <div className="submenu">
//           {items.map((item, index) => (
//             <a key={index} href="#">
//               {item}
//             </a>
//           ))}
//         </div>
//       )}
//     </div>
//   );
// };

// export default SubMenu;
