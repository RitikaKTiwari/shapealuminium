import React from 'react';
import './Card1.css';
import paper12 from '../Images/paper12.png';

const Card2 = () => {
  return (
    <div className="card1-vid">
      <img src={paper12} />
      <div className="card1-content-div">
      </div>
    </div>
  );
};
export default Card2;