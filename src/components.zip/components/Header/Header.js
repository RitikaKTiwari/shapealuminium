// import React, { useState, useRef, useEffect } from "react";
// import { FaSearch } from "react-icons/fa";
// import "./Header.css";
// import "@fontsource/eb-garamond";
// import { useNavigate } from "react-router-dom";
// import SubMenu from "../SubMenu/SubMenu";

// const sampleItems = [
//   "Fine Paper",
//   "Covering Material",
//   "Commodity Paper",
//   "About Us",
//   "Contact Us",
//   "Office Supplies",
//   "Printing Paper",
//   "Stationery",
// ];

// const Header = () => {
//   const [searchQuery, setSearchQuery] = useState("");
//   const [showSearch, setShowSearch] = useState(false);
//   const searchRef = useRef(null);

//   const handleSearchChange = (e) => setSearchQuery(e.target.value);
//   const toggleSearch = () => setShowSearch(true);

//   // Filter search results
//   const filteredItems = sampleItems.filter((item) =>
//     item.toLowerCase().includes(searchQuery.toLowerCase())
//   );

//   // Close search bar when clicking outside
//   useEffect(() => {
//     const handleClickOutside = (event) => {
//       if (searchRef.current && !searchRef.current.contains(event.target)) {
//         setShowSearch(false);
//       }
//     };

//     document.addEventListener("mousedown", handleClickOutside);
//     return () => document.removeEventListener("mousedown", handleClickOutside);
//   }, []);

//   const navigate = useNavigate();
//   const [isMenuOpen, setIsMenuOpen] = useState(false);

//   const toggleMenu = () => {
//     setIsMenuOpen((prev) => !prev);
//   };

//   const handleNavigation = () => {
//     navigate("/ContactUs");
//     setIsMenuOpen(false);
//   };

//   return (
//     <header className="header">
//       <div className="logo">
//         <div className="aum">AUM</div>
//         <div className="enterprises">Enterprises</div>
//       </div>

//       {/* Burger Menu (Only Visible on Mobile) */}
//       <button className="menu-toggle" onClick={toggleMenu}>
//         ☰
//       </button>

//       {/* Navigation Links */}
//       <nav className={`nav ${isMenuOpen ? "open" : ""}`}>
//         <a href="#">Home</a>
//         <SubMenu title="Fine Paper" items={["Luxury Paper", "Coated Paper", "Recycled Paper"]} />
//         <SubMenu title="Covering Material" items={["Leatherette", "Linen", "Embossed"]} />
//         <SubMenu title="Commodity Paper" items={["Kraft Paper", "Newsprint", "Bond Paper"]} />
//         <a href="#" onClick={() => navigate("/AboutUs")}>About Us</a>
//         <a onClick={handleNavigation} style={{ cursor: "pointer" }}>Contact Us</a>
//       </nav>

//       {/* Search & Login */}
//       <div className="header-actions">
//         <FaSearch className="search-icon" onClick={toggleSearch} />

//         {showSearch && (
//           <div ref={searchRef} className="search-container">
//             <input
//               type="text"
//               className="search-input"
//               placeholder="Search..."
//               value={searchQuery}
//               onChange={handleSearchChange}
//               autoFocus
//             />
//             {searchQuery && (
//               <div className="search-results-container">
//                 <ul className="search-results">
//                   {filteredItems.length > 0 ? (
//                     filteredItems.map((item, index) => <li key={index}>{item}</li>)
//                   ) : (
//                     <li>No results found</li>
//                   )}
//                 </ul>
//               </div>
//             )}
//           </div>
//         )}

//         <button className="login-btn">LOG IN</button>
//       </div>
//     </header>
//   );
// };

// export default Header;





import React, { useState, useRef, useEffect } from "react";
import { FaSearch, FaChevronDown, FaChevronUp } from "react-icons/fa";
import "./Header.css";
import "@fontsource/eb-garamond";
import SubMenu from "../SubMenu/SubMenu";
import logo from "../Images/image.png";

const sampleItems = [
  "Fine Paper",
  "Covering Material",
  "Commodity Paper",
  "About Us",
  "Contact Us",
  "Office Supplies",
  "Printing Paper",
  "Stationery",
];

const Header = ({ changePage }) => {
  const [searchQuery, setSearchQuery] = useState("");
  const [showSearch, setShowSearch] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isProductsHovered, setIsProductsHovered] = useState(false);

  const searchRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (searchRef.current && !searchRef.current.contains(event.target)) {
        setShowSearch(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const handleNavigation = (page) => {
    changePage(page);
    setIsMenuOpen(false);
    window.scrollTo(0, 0);
  };

  return (
    <header className="header">
      <div className="logo">
        <img src={logo} height={60} alt="AUM Enterprises" />
      </div>

      <button className="menu-toggle" onClick={toggleMenu}>
        ☰
      </button>

      <nav className={`nav ${isMenuOpen ? "open" : ""}`}>
        <a onClick={() => handleNavigation("home")} style={{ cursor: "pointer" }}>
          Home
        </a>

        {/* Products with Up/Down Arrow */}
        {/* <div
          className="products-menu"
          onMouseEnter={() => setIsProductsHovered(true)}
          onMouseLeave={() => setIsProductsHovered(false)}
        >
          <a style={{ cursor: "pointer" }}>
            Products {isProductsHovered ? <FaChevronUp /> : <FaChevronDown />}
          </a>
          {isProductsHovered && (
            <SubMenu items={["Kraft Paper", "Newsprint", "Bond Paper"]} />
          )}
        </div> */}
        <nav>
          <div
            className="products-menu"
            onMouseEnter={() => setIsProductsHovered(true)}
            onMouseLeave={() => setIsProductsHovered(false)}
          >
            <div className="menu-title">
              <span style={{fontWeight: 600}}>Products</span>
              <FaChevronDown className={`chevron ${isProductsHovered ? "rotate" : ""}`} />
            </div>
            {isProductsHovered && <SubMenu items={["Kraft Paper", "Newsprint", "Bond Paper"]} />}
          </div>
        </nav>


        <a onClick={() => handleNavigation("about")} style={{ cursor: "pointer" }}>
          About Us
        </a>
        <a onClick={() => handleNavigation("contact")} style={{ cursor: "pointer" }}>
          Contact Us
        </a>
      </nav>

      <div className="header-actions">
        <FaSearch className="search-icon" onClick={() => setShowSearch(true)} />

        {showSearch && (
          <div ref={searchRef} className="search-container">
            <input
              type="text"
              className="search-input"
              placeholder="Search..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              autoFocus
            />
            {searchQuery && (
              <div className="search-results-container">
                <ul className="search-results">
                  {sampleItems.filter((item) =>
                    item.toLowerCase().includes(searchQuery.toLowerCase())
                  ).length > 0 ? (
                    sampleItems
                      .filter((item) => item.toLowerCase().includes(searchQuery.toLowerCase()))
                      .map((item, index) => <li key={index}>{item}</li>)
                  ) : (
                    <li>No results found</li>
                  )}
                </ul>
              </div>
            )}
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;
