import React, { useState } from "react";
import Header from "../Header/Header";
import Footer from "../Footer/Footer";
import CardSliding from "../Cards/CardSliding";
import ProductGrid from "../ProductGrid/ProductGrid";
import './Home.css';

const Home = ({ changePage }) => {
    const [isModalOpen, setIsModalOpen] = useState(false);

    return (
        <div className="home-container">

            <main className="home-content">
                <CardSliding isPaused={isModalOpen} />
                <ProductGrid setIsModalOpen={setIsModalOpen} changePage={changePage} />
            </main>

        </div>
    );
};

export default Home;
