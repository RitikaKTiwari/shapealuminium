import React, { useEffect } from "react";
import "./AboutUs.css";
import paper1 from "../Images/paper1.jpg";
import paper2 from "../Images/paper12.png";
import Header from "../Header/Header";
import Footer from "../Footer/Footer";

const AboutUs = () => {
  useEffect(() => {
    const handleScroll = () => {
      const contentSection = document.querySelector(".content");
      const featuresSection = document.querySelector(".features");
      const imageContent = document.querySelector(".image-content");

      if (contentSection && window.scrollY > contentSection.offsetTop - window.innerHeight / 1.3) {
        contentSection.style.opacity = "1";
        contentSection.style.transform = "translateY(0)";
      }

      if (featuresSection && window.scrollY > featuresSection.offsetTop - window.innerHeight / 1.3) {
        featuresSection.style.opacity = "1";
        featuresSection.style.transform = "translateY(0)";
      }

      if (imageContent && window.scrollY > imageContent.offsetTop - window.innerHeight / 1.3) {
        imageContent.classList.add("visible");
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <div className="about-container">
      {/* Hero Section */}
      <div className="hero-section">
        <img src={paper1} alt="Paper Rolls" className="hero-image" />
        <div className="hero-overlay">
          <h1>About Us</h1>
          <p>Home &gt; About Us</p>
        </div>
      </div>

      {/* Content Section */}
      <section className="content">
        <div className="text-content">
          <h2>
            <span>Leading Supplier of High-Quality Paper</span>
          </h2>
          <p>
            We are a trusted name in the paper industry, providing premium-quality paper
            for printing, packaging, and office use. With a commitment to sustainability
            and innovation, we ensure our products meet global standards.
          </p>
          <button className="btn">Explore Our Products</button>
          <p className="contact">
            Call Us: <strong>+91 903 707 2250</strong>
          </p>
        </div>

        <div className="image-content">
          <img src={paper2} alt="Paper Manufacturing" className="main-img" />
          <div className="experience-box">
            <p>25+<br /> Years Of Excellence</p>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="features">
        <div className="feature">
          <h3>Premium Quality</h3>
          <p>Our paper products are made from the finest raw materials, ensuring durability and a smooth finish.</p>
        </div>
        <div className="feature">
          <h3>Eco-Friendly Solutions</h3>
          <p>We prioritize sustainable practices and offer recyclable and biodegradable paper options.</p>
        </div>
        <div className="feature">
          <h3>Custom Orders</h3>
          <p>We provide tailored solutions for bulk orders, catering to industries, businesses, and individuals.</p>
        </div>
      </section>
    </div>
  );
};

export default AboutUs;



// import React from "react";
// import { useNavigate } from "react-router-dom";
// import "./AboutUs.css"; // Import the CSS file for styling
// import Header from "../Header/Header"; // Import Header component
// import Footer from "../Footer/Footer"; // Import Footer component
// import { IconButton } from "@mui/material";
// import ArrowBackIcon from "@mui/icons-material/ArrowBack";

// const AboutUs = () => {
//     const navigate = useNavigate();
//     return (
//         <div>
//             <Header /> {/* Add Header at the top */}
//             <div className="about-us-container">
//                 <div className="about-us-content">
//                     <div>
//                         <IconButton
//                             onClick={() => {
//                                 navigate(-1);
//                             }}
//                             aria-label="back"
//                         >
//                             <ArrowBackIcon />
//                         </IconButton>
//                     </div>
//                     <h1 className="about-us-title">About Us</h1>
//                     <p className="about-us-description">
//                         At AUM Enterprise, we take pride in being a trusted distributor of high-quality paper products,
//                         serving businesses across PAN India with prompt and reliable deliveries. Our commitment lies in
//                         understanding our customers' unique needs and providing them with the finest paper solutions.
//                     </p>

//                     <section className="about-us-section">
//                         <h2 className="about-us-subtitle">Our Mission</h2>
//                         <p className="about-us-text">
//                             At AUM Enterprise,we strive for excellence in every sheet we deliver, ensuring quality,
//                             consistency, and customer satisfaction.
//                         </p>
//                     </section>

//                     <section className="about-us-section">
//                         <h2 className="about-us-subtitle">What We Offer</h2>
//                         <ul className="about-us-list">
//                             <li className="about-us-list-item">
//                                 Our diverse clientele includes publishers, printers,
//                                 newspapers, exporters, government organizations, banks, and many more.
//                             </li>
//                             <li className="about-us-list-item">
//                                 From catering to local and national clients to fulfilling the demands of our
//                                 esteemed international partners, we specialize in the export of color paper and
//                                 kraft paper while also importing premium specialty papers and covering materials.
//                             </li>
//                         </ul>
//                     </section>

//                     <section className="about-us-section">
//                         <h2 className="about-us-subtitle">Our Team</h2>
//                         <p className="about-us-text">
//                             Our team consists of dedicated professionals who are passionate
//                             about bridging the gap between businesses and users. We are
//                             committed to constantly improving our platform to provide the best
//                             experience for everyone.
//                         </p>
//                     </section>
//                 </div>
//                 <Footer /> {/* Add Footer at the bottom */}
//             </div>
//         </div>
//     );
// };

// export default AboutUs;
