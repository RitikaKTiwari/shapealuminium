// BathroomCard.jsx
import React from 'react';
import './Card1.css';
import paper4 from '../Images/paper4.png';

const BathroomCard = () => {
  return (
    <div className="card1-vid">
      {/* <video className="card1-background-video" autoPlay loop muted>
            <source src={paper1} type="video/mp4/jpg" />
            Your browser does not support the video tag.
          </video> */}
      <img src={paper4} />
      <div className="card1-content-div">
        {/* <div>
              <div>Get squeaky clean bathrooms</div>
            </div>*/}
        {/* <button className="card1-content">
          Explore Now
        </button> */}
      </div>
    </div>
  );
};

export default BathroomCard;
